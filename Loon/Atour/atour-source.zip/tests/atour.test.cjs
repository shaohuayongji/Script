"use strict";

// 黑盒模拟 Loon API。测试没有真实账号，也不会发起任何网络请求。
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const test = require("node:test");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(path.join(root, "atour.loon.js"), "utf8");
const KEY = "atour_loon_session_v1";
const CANDIDATE_KEY = "atour_loon_candidate_v1";
const captureSource = fs.readFileSync(path.join(root, "atour.capture.js"), "utf8");
const HOST = "miniapp.yaduo.com";
const INDEX = "/atourlife/signIn/indexInfoV2";
const SIGN = "/atourlife/signIn/signIn";
const TOKEN = "fake-token-secret-local-0001";
const NEW_TOKEN = "fake-token-secret-local-0002";
const HEADER_SECRET = "fake-header-secret-local-0001";
const CAPTCHA_SECRET = "fake-captcha-secret-local-0001";
const PRIVATE_NAME = "fake-person-private-name";
const PRIVATE_MOBILE = "13900009991";
const query = token => "token=" + token + "&platType=5&appVer=4.19.0&channelId=300001&r=123";
const urlFor = (pathname, token = TOKEN) => "https://" + HOST + pathname + "?" + query(token);
const headers = () => ({
  "User-Agent": "Test-Atour-UA",
  Authorization: HEADER_SECRET,
  "Content-Type": "application/json"
});
const saved = extra => ({
  [KEY]: JSON.stringify({ url: urlFor(INDEX), headers: headers(), savedAt: Date.now(), ...extra })
});
const ok = result => ({ retcode: 0, result });
const state = (complete, extra) => ok({ todaySignInComplete: complete, ...extra });
const indexStep = data => ({ pathname: INDEX, data });
const signStep = data => ({ pathname: SIGN, data });
const localDay = () => {
  const d = new Date();
  return [d.getFullYear(), d.getMonth() + 1, d.getDate()].map((n, i) => i ? String(n).padStart(2, "0") : String(n)).join("-");
};

// 来自官方公开 H5 模块 109 的通用协议常量，并非账号凭据。
// AES fixture 由 Node/OpenSSL 生成，不调用被测脚本里的 CryptoJS。
const AES_KEY = Buffer.from("9vok8x4yri507ngmplhs3uq6cfbz2a1t", "utf8");
const AES_IV = Buffer.from("e9yu7sz2xrn30bf5", "utf8");
function encryptAES(value) {
  const cipher = crypto.createCipheriv("aes-256-cbc", AES_KEY, AES_IV);
  return Buffer.concat([cipher.update(JSON.stringify(value), "utf8"), cipher.final()]).toString("base64url");
}
const aesStep = step => ({ ...step, body: encryptAES(step.data), responseHeaders: { "x-encryption": "2" } });
// 预先生成的合成 SM2 fixtures；测试运行时不依赖 vendor 库或网络。
const SM2_FIXTURES = require("./fixtures/sm2.json").samples;
const sm2Step = (step, fixture) => ({
  ...step,
  body: SM2_FIXTURES[fixture].ciphertext,
  responseHeaders: { "X-Encryption": "1" }
});

async function simulate({ storage = {}, request, response, steps = [], writeFails = false, forbidBodyRead = false, forceRunner = false, fault } = {}) {
  const values = new Map(Object.entries(storage));
  const calls = [];
  const notifications = [];
  const logs = [];
  const completions = [];
  let resolveDone;
  let rejectDone;
  const completion = new Promise((resolve, reject) => { resolveDone = resolve; rejectDone = reject; });
  const original = JSON.stringify({ request, response });
  const context = {
    console: Object.fromEntries(["log", "warn", "error", "info"].map(method => [method, (...args) => { if (fault === "log") throw new Error(TOKEN); logs.push(args.map(String).join(" ")); }])),
    $loon: {},
    $persistentStore: {
      read: key => { if (fault === "read") throw new Error(TOKEN); return values.get(key) ?? null; },
      write: (value, key) => {
        if (fault === "write") throw new Error(TOKEN);
        if (writeFails) return false;
        if (value === undefined) { values.delete(key); return true; }
        values.set(key, value);
        return true;
      }
    },
    $notification: { post: (...args) => { if (fault === "notice") throw new Error(TOKEN); notifications.push(args); } },
    $done: (...args) => { completions.push(args); resolveDone(); },
    setTimeout,
    clearTimeout
  };
  context.$httpClient = {};
  for (const method of ["get", "post", "put", "delete", "head"]) {
    context.$httpClient[method] = (options, callback) => {
      calls.push({ method, options });
      const expected = steps[calls.length - 1];
      try {
        assert.ok(expected, "Unexpected outbound request");
        assert.equal(method, expected.method ?? "get");
        const url = new URL(options.url);
        assert.equal(url.protocol, "https:");
        assert.equal(url.hostname, HOST);
        assert.equal(url.pathname, expected.pathname, "Outbound endpoint sequence changed");
        const originalUrl = new URL(expected.originalUrl ?? urlFor(INDEX));
        for (const [key, value] of originalUrl.searchParams) {
          if (key !== "r") assert.equal(url.searchParams.get(key), value, "A captured login query value changed");
        }
        const lowerHeaders = Object.fromEntries(Object.entries(options.headers ?? {}).map(([k, v]) => [k.toLowerCase(), v]));
        assert.equal(lowerHeaders.authorization, HEADER_SECRET);
        for (const key of ["host", "content-length", "connection", "accept-encoding", "lotnumber", "captchaoutput", "passtoken", "gentime", "lacktype", "at-client-sign"]) {
          assert.equal(lowerHeaders[key], undefined, "Unsafe replay header remained: " + key);
        }
        expected.inspect?.({ url, options, lowerHeaders });
      } catch (error) {
        rejectDone(error);
        return;
      }
      // Loon callbacks are asynchronous; never execute the next network step inline.
      queueMicrotask(() => {
        try {
          expected.mutateStorage?.(values);
          callback(expected.error ?? null, {
            status: expected.status ?? 200,
            headers: expected.responseHeaders ?? {}
          }, expected.body ?? JSON.stringify(expected.data));
        } catch (error) { rejectDone(error); }
      });
    };
  }
  if (request) context.$request = forbidBodyRead ? new Proxy(request, { get: (obj, key) => { assert.notEqual(key, "body", "Capture read request body"); return obj[key]; } }) : request;
  if (response) context.$response = forbidBodyRead ? new Proxy(response, { get: () => { throw new Error("Capture read response"); } }) : response;
  let result;
  let timer;
  try {
    result = vm.runInNewContext(request && !forceRunner ? captureSource : source, context, { timeout: 1000 });
    await Promise.race([completion, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error("$done was not called")), 1000);
    })]);
    await result;
    await new Promise(resolve => setImmediate(resolve));
  } finally {
    clearTimeout(timer);
  }
  assert.equal(calls.length, steps.length, "Missing expected outbound request");
  assert.equal(completions.length, 1, "$done must be called exactly once");
  assert.equal(JSON.stringify(completions[0]), request ? "[{}]" : "[]", "The intercepted response must pass through unchanged");
  assert.equal(JSON.stringify({ request, response }), original, "The original traffic was mutated");
  const publicOutput = JSON.stringify({ logs, notifications });
  for (const secret of [TOKEN, NEW_TOKEN, HEADER_SECRET, CAPTCHA_SECRET, PRIVATE_NAME, PRIVATE_MOBILE]) {
    assert.ok(!publicOutput.includes(secret), "A private value escaped to logs or a notification");
  }
  assert.ok(!publicOutput.includes("https://" + HOST), "A complete account request URL escaped to public output");
  return {
    values, calls, notifications, logs,
    session: () => values.has(KEY) ? JSON.parse(values.get(KEY)) : undefined,
    candidate: () => values.has(CANDIDATE_KEY) ? JSON.parse(values.get(CANDIDATE_KEY)) : undefined,
    message: () => notifications.flat().join("\n")
  };
}

function capture(pathname = INDEX, result = { todaySignInComplete: false }) {
  return {
    request: { url: urlFor(pathname, NEW_TOKEN), method: "GET", headers: headers() },
    response: { status: 200, headers: {}, body: JSON.stringify(ok(result)) }
  };
}

test("a status request saves an unvalidated candidate without changing traffic", async () => {
  const result = await simulate(capture());
  assert.equal(result.candidate().url, urlFor(INDEX, NEW_TOKEN));
  assert.equal(result.candidate().headers.Authorization, HEADER_SECRET);
  assert.ok(result.candidate().savedAt);
  for (const key of ["headers", "savedAt", "url"]) assert.ok(Object.hasOwn(result.candidate(), key));
  assert.equal(Object.hasOwn(result.candidate(), "result"), false);
  assert.match(result.message(), /保存|获取|更新/);
});

test("capture ignores sign submission requests and preserves the verified session", async () => {
  const storage = saved({ signedDay: localDay() });
  const result = await simulate({ ...capture(SIGN), storage });
  assert.equal(result.values.get(KEY), storage[KEY]);
  assert.equal(result.candidate(), undefined);
});

test("capture excludes transport headers and single-use captcha fields case-insensitively", async () => {
  const cap = capture();
  Object.assign(cap.request.headers, {
    Host: HOST, "Content-Length": "0", CONNECTION: "keep-alive", "Accept-Encoding": "gzip",
    Lotnumber: CAPTCHA_SECRET, CAPTCHAOUTPUT: CAPTCHA_SECRET, passtoken: CAPTCHA_SECRET,
    Gentime: CAPTCHA_SECRET, Lacktype: "geetest"
  });
  const result = await simulate(cap);
  const keys = Object.keys(result.candidate().headers).map(k => k.toLowerCase());
  for (const key of ["host", "content-length", "connection", "accept-encoding", "lotnumber", "captchaoutput", "passtoken", "gentime", "lacktype"]) {
    assert.ok(!keys.includes(key));
  }
  assert.match(result.logs.join("\n"), /captchaHeadersStored=false/);
});

test("request-only capture ignores response validity and keeps the verified session", async () => {
  for (const mutate of [
    cap => { cap.response.status = 503; },
    cap => { cap.response.body = JSON.stringify({ retcode: 10002, retmsg: "token expired" }); },
    cap => { cap.response.body = "not-json"; },
    cap => { cap.response.body = JSON.stringify({ result: { todaySignInComplete: false } }); }
  ]) {
    const cap = capture();
    mutate(cap);
    const storage = saved();
    const result = await simulate({ ...cap, storage });
    assert.equal(result.values.get(KEY), storage[KEY]);
  }
});

test("coercible non-integer retcodes never permit submission or a false complete state", async () => {
  for (const retcode of [[], {}, [0], false, null, "", "0.0", "0x0", "0e0", " 0 "]) {
    const result = await simulate({ storage: saved(), steps: [indexStep({ retcode, result: { todaySignInComplete: true } })] });
    assert.doesNotMatch(result.message(), /签到成功|今日已签到/);
    assert.notEqual(result.session().signedDay, localDay());
  }
});

test("opening the same account with a fresh r parameter updates storage quietly", async () => {
  const cap = capture();
  cap.request.url = urlFor(INDEX, TOKEN).replace("&r=123", "&r=456");
  const result = await simulate({ ...cap, storage: { ...saved(), [CANDIDATE_KEY]: JSON.stringify({ url: urlFor(INDEX), headers: headers() }) } });
  assert.equal(result.candidate().url, cap.request.url);
  assert.equal(result.notifications.length, 0);
});

test("an unrelated host, HTTP URL, suffix, or path cannot replace a session", async () => {
  for (const url of [
    "http://" + HOST + INDEX + "?" + query(NEW_TOKEN),
    "https://" + HOST + ".example.org" + INDEX + "?" + query(NEW_TOKEN),
    "https://example.org/" + HOST + INDEX + "?" + query(NEW_TOKEN),
    urlFor(INDEX + "Extra", NEW_TOKEN),
    urlFor("/atourlife/signIn/lottery", NEW_TOKEN)
  ]) {
    const cap = capture();
    cap.request.url = url;
    const storage = saved();
    const result = await simulate({ ...cap, storage });
    assert.equal(result.values.get(KEY), storage[KEY]);
  }
});

test("At-Client-Sign does not discard login information and is never persisted", async () => {
  for (const key of ["At-Client-Sign", "at-client-sign", "AT-CLIENT-SIGN"]) {
    const cap = capture();
    cap.request.headers[key] = CAPTCHA_SECRET;
    const result = await simulate(cap);
    assert.equal(result.candidate().url, urlFor(INDEX, NEW_TOKEN));
    assert.equal(result.candidate().capturedWithDynamicSign, true);
    assert.ok(!Object.keys(result.candidate().headers).some(name => name.toLowerCase() === "at-client-sign"));
    assert.match(result.message(), /候选/);
    assert.doesNotMatch(result.message(), /签到成功|今日已签到/);
  }
});

test("a session captured with a signature can sign only after a server-accepted ordinary status query", async () => {
  const cap = capture();
  cap.request.headers["At-Client-Sign"] = CAPTCHA_SECRET;
  const captured = await simulate(cap);
  const steps = [indexStep(state(false)), signStep(ok({ debrisDesc: "获得 1 片碎片" })), indexStep(state(true))]
    .map(step => ({ ...step, originalUrl: urlFor(INDEX, NEW_TOKEN) }));
  const result = await simulate({ storage: Object.fromEntries(captured.values), steps });
  assert.match(result.message(), /签到成功/);
  assert.equal(result.candidate(), undefined);
  assert.equal(result.session().url, urlFor(INDEX, NEW_TOKEN));
});

test("a rejected ordinary status query stops before signing a session captured with a signature", async () => {
  const result = await simulate({ storage: saved({ capturedWithDynamicSign: true }), steps: [indexStep({ retcode: 10003 })] });
  assert.match(result.message(), /普通查询未通过/);
  assert.match(result.message(), /10003/);
  assert.doesNotMatch(result.message(), /签到成功|今日已签到/);
  assert.equal(result.session().signedDay, undefined);
});

test("captcha and expired login responses still stop ordinary status validation", async () => {
  for (const code of [100042, 10002]) {
    const result = await simulate({ storage: saved({ capturedWithDynamicSign: true }), steps: [indexStep({ retcode: code })] });
    assert.match(result.message(), code === 100042 ? /人工验证/ : /重新登录/);
    assert.doesNotMatch(result.message(), /签到成功|今日已签到/);
  }
});

test("dynamic query rejection names fields while preserving the old session and hiding values", async () => {
  for (const field of ["SIGN", "signature", "nonce", "timestamp", "ts", "Lotnumber", "captchaoutput", "passtoken", "gentime", "lacktype"]) {
    const cap = capture();
    cap.request.url += "&" + field + "=" + CAPTCHA_SECRET;
    cap.request.headers["At-Client-Sign"] = HEADER_SECRET;
    const storage = saved();
    const result = await simulate({ ...cap, storage });
    assert.equal(result.values.get(KEY), storage[KEY]);
    assert.match(result.message(), /需要参数适配/);
    assert.ok(result.message().includes(field.toLowerCase()));
  }
});

test("a legacy stored signature header cannot be replayed", async () => {
  const result = await simulate({ storage: saved({ headers: { ...headers(), "At-Client-Sign": CAPTCHA_SECRET } }) });
  assert.match(result.message(), /尚未获取/);
});

test("a failed persistent-store write cannot report successful capture", async () => {
  const result = await simulate({ ...capture(), writeFails: true });
  assert.equal(result.values.has(KEY), false);
  assert.match(result.message(), /失败|未能|无法/);
});

test("no captured session means no network request", async () => {
  const result = await simulate();
  assert.match(result.message(), /登录|捕获|获取/);
});

test("corrupt or untrusted stored session URLs are refused before networking", async () => {
  for (const value of [
    "not-json",
    JSON.stringify({ url: "https://evil.example" + INDEX, headers: headers() }),
    JSON.stringify({ url: urlFor(SIGN), headers: headers() }),
    JSON.stringify({ url: "http://" + HOST + INDEX, headers: headers() }),
    JSON.stringify({ url: "https://" + HOST + ".evil.example" + INDEX, headers: headers() })
  ]) {
    const result = await simulate({ storage: { [KEY]: value } });
    assert.match(result.message(), /登录|捕获|获取|无效|不支持/);
  }
});

test("a successful status query skips submission when today is complete", async () => {
  const result = await simulate({ storage: saved(), steps: [indexStep(state(true))] });
  assert.match(result.message(), /已签到|已完成/);
  assert.equal(result.session().signedDay, localDay());
});

test("a local signed marker never bypasses authoritative status querying", async () => {
  const result = await simulate({ storage: saved({ signedDay: localDay() }), steps: [
    indexStep(state(false)), signStep(ok({ debrisDesc: "获得 1 片碎片" })), indexStep(state(true))
  ] });
  assert.match(result.message(), /签到成功|签到完成/);
});

test("capturing a different account cannot carry over an old signed marker", async () => {
  const result = await simulate({ ...capture(), storage: saved({ signedDay: localDay() }) });
  assert.equal(result.candidate().url, urlFor(INDEX, NEW_TOKEN));
  assert.notEqual(result.candidate().signedDay, localDay());
});

test("a check-in succeeds only after the complete GET status, sign, status sequence", async () => {
  const result = await simulate({ storage: saved(), steps: [
    indexStep(state(false)),
    signStep(ok({ debrisDesc: "获得 1 片碎片" })),
    indexStep(state(true))
  ] });
  assert.match(result.message(), /签到成功|签到完成/);
  assert.match(result.message(), /1/);
  assert.equal(result.session().signedDay, localDay());
});

test("a completed old account task cannot overwrite a newly captured account", async () => {
  const replacement = JSON.stringify({ url: urlFor(INDEX, NEW_TOKEN), headers: headers(), savedAt: 123456789 });
  const first = indexStep(state(false));
  first.mutateStorage = values => values.set(KEY, replacement);
  const result = await simulate({ storage: saved(), steps: [first, signStep(ok({ debrisDesc: "获得 1 片碎片" })), indexStep(state(true))] });
  assert.equal(result.values.get(KEY), replacement, "Completion of account A overwrote the fresh account B session");
});

test("same-account audit merging preserves newer capture URL and timestamp", async () => {
  const newer = { url: urlFor(INDEX).replace("&r=123", "&r=987"), headers: headers(), savedAt: 987654321 };
  const first = indexStep(state(false));
  first.mutateStorage = values => values.set(KEY, JSON.stringify(newer));
  const result = await simulate({ storage: saved(), steps: [first, signStep(ok({ debrisDesc: "获得 1 片碎片" })), indexStep(state(true))] });
  assert.equal(result.session().url, newer.url);
  assert.equal(result.session().savedAt, newer.savedAt);
  assert.equal(result.session().signedDay, localDay());
});

test("a task cannot resurrect its old session after stored data becomes invalid", async () => {
  const first = indexStep(state(false));
  first.mutateStorage = values => values.set(KEY, "not-json-after-login-change");
  const result = await simulate({ storage: saved(), steps: [first, signStep(ok({ debrisDesc: "获得 1 片碎片" })), indexStep(state(true))] });
  assert.equal(result.values.get(KEY), "not-json-after-login-change");
});

test("missing or ambiguous status does not permit a sign-in request", async () => {
  for (const data of [ok({}), ok(null), { retcode: 0 }, state("unexpected")]) {
    const result = await simulate({ storage: saved(), steps: [indexStep(data)] });
    assert.doesNotMatch(result.message(), /签到成功/);
    assert.notEqual(result.session().signedDay, localDay());
  }
});

test("retcode 100042 requests manual captcha verification and never retries", async () => {
  for (const steps of [
    [indexStep({ retcode: 100042, retmsg: "请完成验证" })],
    [indexStep(state(false)), signStep({ retcode: 100042, retmsg: "请完成验证" })]
  ]) {
    const result = await simulate({ storage: saved(), steps });
    assert.match(result.message(), /人工|手动|验证/);
    assert.doesNotMatch(result.message(), /签到成功/);
    assert.notEqual(result.session().signedDay, localDay());
  }
});

test("retcode 10002 at either endpoint requests a refreshed login", async () => {
  for (const steps of [
    [indexStep({ retcode: 10002, retmsg: "登录已失效" })],
    [indexStep(state(false)), signStep({ retcode: 10002, retmsg: "登录已失效" })]
  ]) {
    const result = await simulate({ storage: saved(), steps });
    assert.match(result.message(), /登录/);
    assert.doesNotMatch(result.message(), /签到成功/);
  }
});

test("a non-200 status response cannot be mistaken for an authenticated state", async () => {
  for (const status of [302, 401, 403, 500]) {
    const result = await simulate({ storage: saved(), steps: [{ ...indexStep(state(true)), status }] });
    assert.doesNotMatch(result.message(), /签到成功|今日已签到/);
    assert.notEqual(result.session().signedDay, localDay());
  }
});

test("a non-200 sign response is not retried, confirmed, or reported successful", async () => {
  const result = await simulate({ storage: saved(), steps: [
    indexStep(state(false)), { ...signStep(ok({ debrisDesc: "签到成功" })), status: 503 }
  ] });
  assert.doesNotMatch(result.message(), /签到成功/);
  assert.notEqual(result.session().signedDay, localDay());
});

test("network failure before signing stops without submission", async () => {
  const result = await simulate({ storage: saved(), steps: [{ ...indexStep(null), error: "network unavailable" }] });
  assert.doesNotMatch(result.message(), /签到成功/);
});

test("a lost sign response is never automatically replayed", async () => {
  const result = await simulate({ storage: saved(), steps: [
    indexStep(state(false)), { ...signStep(null), error: "network timeout" }
  ] });
  assert.doesNotMatch(result.message(), /签到成功/);
  assert.notEqual(result.session().signedDay, localDay());
});

test("retcode zero submission with a negative or missing recheck remains unconfirmed", async () => {
  for (const last of [indexStep(state(false)), indexStep(ok({})), { ...indexStep(null), error: "network unavailable" }]) {
    const result = await simulate({ storage: saved(), steps: [indexStep(state(false)), signStep(ok({ debrisDesc: "获得 1 片碎片" })), last] });
    assert.doesNotMatch(result.message(), /签到成功/);
    assert.notEqual(result.session().signedDay, localDay());
  }
});

test("unexpected business errors stop without replaying the sign request", async () => {
  const result = await simulate({ storage: saved(), steps: [
    indexStep(state(false)), signStep({ retcode: 999999, retmsg: "服务暂不可用" })
  ] });
  assert.doesNotMatch(result.message(), /签到成功/);
});

test("encrypted non-JSON replies explicitly request protocol adaptation", async () => {
  for (const encryption of ["1", "2"]) {
    const result = await simulate({ storage: saved(), steps: [{
      ...indexStep(null), body: "not-json-encrypted-body", responseHeaders: { "x-encryption": encryption }
    }] });
    assert.match(result.message(), /加密|解密|适配/);
    assert.doesNotMatch(result.message(), /签到成功/);
  }
});

test("AES-encrypted status replies support confirmed daily sign-in", async () => {
  const result = await simulate({ storage: saved(), steps: [
    aesStep(indexStep(state(false))),
    aesStep(signStep(ok({ debrisDesc: "获得 1 片碎片" }))),
    aesStep(indexStep(state(true)))
  ] });
  assert.match(result.message(), /签到成功|签到完成/);
  assert.equal(result.session().signedDay, localDay());
});

test("a valid encrypted duplicate state skips submission", async () => {
  const result = await simulate({ storage: saved(), steps: [aesStep(indexStep(state(true)))] });
  assert.match(result.message(), /已签到|已完成/);
});

test("AES decryption must preserve business failure and never treat it as success", async () => {
  const result = await simulate({ storage: saved(), steps: [aesStep(indexStep({ retcode: 100042, retmsg: "请完成验证" }))] });
  assert.match(result.message(), /人工|手动|验证/);
  assert.doesNotMatch(result.message(), /签到成功/);
});

test("unknown encryption modes fail before interpreting even a valid JSON body", async () => {
  const result = await simulate({ storage: saved(), steps: [{
    ...indexStep(state(true)), responseHeaders: { "X-Encryption": "9" }
  }] });
  assert.match(result.message(), /加密|解析|协议|不支持/);
  assert.doesNotMatch(result.message(), /签到成功|今日已签到/);
  assert.notEqual(result.session().signedDay, localDay());
});

test("SM2-encrypted status and sign replies support confirmed daily sign-in", async () => {
  const result = await simulate({ storage: saved(), steps: [
    sm2Step(indexStep(state(false)), "incomplete"),
    sm2Step(signStep(ok({ debrisDesc: "获得 1 片碎片" })), "signed"),
    sm2Step(indexStep(state(true)), "complete")
  ] });
  assert.match(result.message(), /签到成功|签到完成/);
  assert.equal(result.session().signedDay, localDay());
});

test("SM2 decryption preserves a manual-verification business error", async () => {
  const result = await simulate({ storage: saved(), steps: [
    sm2Step(indexStep({ retcode: 100042, retmsg: "请完成验证" }), "captcha")
  ] });
  assert.match(result.message(), /人工|手动|验证/);
  assert.doesNotMatch(result.message(), /签到成功/);
});

test("SM2 ciphertext with a modified C3 cannot be accepted as a complete state", async () => {
  const bytes = Buffer.from(SM2_FIXTURES.complete.ciphertext, "base64url");
  bytes[bytes.length - 1] ^= 1;
  const result = await simulate({ storage: saved(), steps: [{
    ...indexStep(null), body: bytes.toString("base64url"), responseHeaders: { "x-encryption": "1" }
  }] });
  assert.match(result.message(), /加密|解密|解析|协议/);
  assert.doesNotMatch(result.message(), /签到成功|今日已签到/);
  assert.notEqual(result.session().signedDay, localDay());
});

test("unencrypted malformed JSON is a failure and never invokes signing", async () => {
  const result = await simulate({ storage: saved(), steps: [{ ...indexStep(null), body: "<html>upstream unavailable</html>" }] });
  assert.doesNotMatch(result.message(), /签到成功/);
});

test("captured common query parameters stay intact on every endpoint", async () => {
  const requestUrl = urlFor(INDEX) + "&encoded=a%2Bb%26c&deviceId=fake-device&zero=0";
  const storage = saved({ url: requestUrl });
  const steps = [indexStep(state(false)), signStep(ok({ debrisDesc: "获得 1 片碎片" })), indexStep(state(true))]
    .map(step => ({ ...step, originalUrl: requestUrl, inspect: ({ url }) => {
      assert.equal(url.searchParams.get("encoded"), "a+b&c");
      assert.equal(url.searchParams.get("zero"), "0");
      assert.equal(url.searchParams.get("deviceId"), "fake-device");
    } }));
  await simulate({ storage, steps });
});

test("response details and error strings cannot disclose account secrets", async () => {
  const sensitive = TOKEN + " " + HEADER_SECRET + " " + PRIVATE_NAME + " " + PRIVATE_MOBILE;
  const responses = [
    [indexStep({ retcode: 999999, retmsg: sensitive })],
    [indexStep(state(false)), { ...signStep(null), error: sensitive }],
    [indexStep(state(false)), signStep(ok({ debrisDesc: sensitive })), indexStep(state(true))]
  ];
  for (const steps of responses) await simulate({ storage: saved(), steps });
});

test("diagnostic logs identify the failing phase and code without recording response details", async () => {
  const result = await simulate({ storage: saved(), steps: [
    indexStep(state(false)), signStep({ retcode: 100042, retmsg: TOKEN, result: { name: PRIVATE_NAME, mobile: PRIVATE_MOBILE } })
  ] });
  const logs = result.logs.join("\n");
  assert.match(logs, /\[ATOUR 2026\.10\.04\.4 [0-9a-f]+\] start mode=checkin/);
  assert.match(logs, /request\.response endpoint=indexInfoV2 HTTP=200 encryption=none/);
  assert.match(logs, /state\.before todaySigned=false/);
  assert.match(logs, /request\.decode endpoint=signIn retcode=100042/);
  assert.match(logs, /finish mode=checkin/);
  assert.doesNotMatch(logs, /state\.after|retmsg=|Authorization|Cookie|token=/);
});

test("unknown code 100014 is not assigned a fixed meaning and only allowlisted message tags escape", async () => {
  for (const [retmsg,tag] of [
    ["签名校验失败：" + TOKEN + " " + PRIVATE_NAME + " " + PRIVATE_MOBILE, "signature"],
    ["验证码错误：" + CAPTCHA_SECRET, "verification"],
    ["系统繁忙：" + HEADER_SECRET, "server"],
    [TOKEN + " " + PRIVATE_NAME, "unclassified"],
    [null, "unclassified"],
    [{ reason: "签名错误", token: TOKEN }, "unclassified"]
  ]) {
    const result = await simulate({ storage: saved(), steps: [indexStep(state(false)), signStep({ retcode: 100014, retmsg })] });
    const logs = result.logs.join("\n");
    assert.match(logs, new RegExp("endpoint=signIn retcode=100014 retmsgPresent=(?:true|false) retmsgTags=" + tag));
    assert.match(result.message(), /签到请求未通过/);
    assert.doesNotMatch(result.message(), /签到成功|今日已签到|需要人工验证|需要重新登录/);
    assert.ok(!logs.includes("签名校验失败："));
    assert.ok(!logs.includes("验证码错误："));
    assert.equal(result.session().signedDay, undefined);
  }
});

test("daily plugins contain no traffic interception or MitM and temporary capture reads no body", () => {
  const localPlugin = path.join(root, "AtourCheckIn.local.plugin");
  const plugin = fs.readFileSync(fs.existsSync(localPlugin) ? localPlugin : path.join(root, "AtourCheckIn.plugin"), "utf8");
  const snippet = fs.readFileSync(path.join(root, "loon-snippet.conf"), "utf8");
  const lines = text => text.split("\n").filter(line => /^(http-request|http-response|cron|generic) /.test(line));
  assert.deepEqual(lines(plugin), lines(snippet));
  for (const text of [plugin, snippet, fs.readFileSync(fs.existsSync(path.join(root, "remote/AtourCheckIn.plugin")) ? path.join(root, "remote/AtourCheckIn.plugin") : path.join(root, "AtourCheckIn.plugin"), "utf8")]) {
    assert.doesNotMatch(text, /http-request|http-response|\[Mitm\]|hostname=/i);
    assert.equal(lines(text).length, 2);
  }
  const localCapture = path.join(root, "AtourCapture.local.plugin");
  const capturePlugin = fs.readFileSync(fs.existsSync(localCapture) ? localCapture : path.join(root, "AtourCapture.plugin"), "utf8");
  const line = lines(capturePlugin)[0];
  assert.equal(lines(capturePlugin).length, 1);
  assert.ok(line.startsWith("http-request "));
  assert.ok(line.includes("requires-body=false"));
  assert.ok(line.includes("script-path=atour.capture.js"));
  const pattern = new RegExp(line.split(" ")[1]);
  assert.ok(pattern.test(urlFor(INDEX)));
  for (const url of [urlFor(SIGN), urlFor(INDEX + "Extra"), urlFor("/atourlife/signIn/lottery"), "https://" + HOST + ".evil.example" + INDEX]) assert.ok(!pattern.test(url));
  assert.doesNotMatch(captureSource, /__atourCrypto|\$httpClient|\$response|\$request\.body/);
});

test("request capture never reads response or request body, including binary or encrypted bodies", async () => {
  for (const body of ["not-json", encryptAES(state(true)), Uint8Array.from([255, 0, 128])]) {
    const cap = capture();
    cap.request.body = body;
    cap.response.body = body;
    const storage = saved();
    const result = await simulate({ ...cap, storage, forbidBodyRead: true });
    assert.ok(result.candidate());
    assert.equal(result.candidate().validatedAt, undefined);
    assert.equal(result.candidate().signedDay, undefined);
    assert.equal(result.values.get(KEY), storage[KEY]);
  }
});

test("local storage, logging and notification exceptions cannot prevent request passthrough", async () => {
  for (const fault of ["read", "write", "log", "notice"]) await simulate({ ...capture(), fault });
});

test("a new candidate is promoted only after a recognized server state", async () => {
  const captured = await simulate({ ...capture(), storage: saved() });
  const storage = Object.fromEntries(captured.values);
  for (const step of [indexStep({ retcode: 10002 }), indexStep(state(null)), { ...indexStep(null), error: "offline" }]) {
    const result = await simulate({ storage, steps: [{ ...step, originalUrl: urlFor(INDEX, NEW_TOKEN) }] });
    assert.equal(result.values.get(KEY), storage[KEY]);
    assert.equal(result.values.get(CANDIDATE_KEY), storage[CANDIDATE_KEY]);
  }
  const success = await simulate({ storage, steps: [{ ...indexStep(state(true)), originalUrl: urlFor(INDEX, NEW_TOKEN) }] });
  assert.equal(success.session().url, urlFor(INDEX, NEW_TOKEN));
  assert.ok(success.session().validatedAt);
  assert.equal(success.candidate(), undefined);
  assert.match(success.message(), /今日已签到/);
});

test("a candidate changed during validation cannot overwrite the saved account or trigger signing", async () => {
  const captured = await simulate({ ...capture(), storage: saved() });
  const storage = Object.fromEntries(captured.values);
  const result = await simulate({ storage, steps: [{ ...indexStep(state(false)), originalUrl: urlFor(INDEX, NEW_TOKEN), mutateStorage: values => values.set(CANDIDATE_KEY, "new-candidate") }] });
  assert.equal(result.values.get(KEY), storage[KEY]);
  assert.equal(result.values.get(CANDIDATE_KEY), "new-candidate");
  assert.match(result.message(), /登录信息已变化/);
});

test("candidate promotion write failure stops before sign submission", async () => {
  const captured = await simulate({ ...capture(), storage: saved() });
  const storage = Object.fromEntries(captured.values);
  const result = await simulate({ storage, writeFails: true, steps: [{ ...indexStep(state(false)), originalUrl: urlFor(INDEX, NEW_TOKEN) }] });
  assert.equal(result.values.get(KEY), storage[KEY]);
  assert.match(result.message(), /保存失败/);
});

test("legacy HTTP rules cannot make the R4 runner read or decode App traffic", async () => {
  const storage = saved();
  const result = await simulate({ ...capture(), storage, forceRunner: true, forbidBodyRead: true });
  assert.equal(result.values.get(KEY), storage[KEY]);
  assert.equal(result.candidate(), undefined);
  assert.match(result.logs.join("\n"), /capture.disabled/);
});
