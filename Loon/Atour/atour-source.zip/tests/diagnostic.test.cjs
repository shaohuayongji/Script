"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const test = require("node:test");
const source = fs.readFileSync(path.join(__dirname, "../atour.diagnostic.js"), "utf8");
const KEY = "atour_loon_app_diagnostic_v1";
const SECRET = "fake-token-signature-credential-secret";
const PII = "13900009991 fake-private-name";
const url = "https://miniapp.yaduo.com/atourlife/signIn/signIn?token=" + SECRET + "&appVer=4.2.0&timestamp=" + SECRET + "&unknown_" + SECRET + "=" + PII;
const request = extra => ({ url, method: "GET", headers: { Authorization: SECRET, "At-Client-Sign": SECRET, "At-Client-Code": SECRET, Lotnumber: SECRET, CAPTCHAOUTPUT: SECRET, passtoken: SECRET, Gentime: SECRET }, body: PII, ...extra });

function run({ req, response, storage = {}, argument = { app_diagnostic: true }, fail, logFails = false } = {}) {
  const values = new Map(Object.entries(storage));
  const logs = [], done = [];
  const before = JSON.stringify({ req, response });
  const context = {
    console: { log: text => { if (logFails) throw new Error(SECRET); logs.push(String(text)); } },
    $persistentStore: {
      read: key => { if (fail === "read") throw new Error(SECRET); return values.get(key); },
      write: (value, key) => { if (fail === "write") throw new Error(SECRET); if (fail === "false") return false; values.set(key, value); return true; }
    },
    $done: (...args) => done.push(args),
    $httpClient: new Proxy({}, { get: () => { throw new Error("diagnostics must not request network"); } }),
    $notification: { post: () => { throw new Error("diagnostics must not post App interception notifications"); } },
    $argument: argument
  };
  // A body read would throw; a resulting swallowed exception would still fail event assertions.
  const protectedTraffic = object => new Proxy(object, { get: (object, key) => {
    assert.notEqual(key, "body", "diagnostic read body");
    return object[key];
  } });
  if (req) context.$request = protectedTraffic(req);
  if (response) context.$response = protectedTraffic(response);
  vm.runInNewContext(source, context, { timeout: 1000 });
  assert.equal(done.length, 1);
  assert.equal(JSON.stringify(done[0]), req ? "[{}]" : "[]");
  assert.equal(JSON.stringify({ req, response }), before);
  const exposed = logs.join("\n") + JSON.stringify(Object.fromEntries(values));
  for (const secret of [SECRET, PII, "https://miniapp.yaduo.com", "13900009991"]) assert.ok(!exposed.includes(secret), "private data escaped");
  return { values, logs, events: () => JSON.parse(values.get(KEY) || "[]") };
}

test("App request diagnosis records only presence and allowlisted field names", () => {
  const result = run({ req: request() });
  const [event] = result.events();
  assert.equal(event.phase, "request");
  assert.equal(event.signHeader, true);
  assert.equal(event.deviceHeader, true);
  assert.equal(event.loginPresent, true);
  assert.deepEqual(event.captchaFields, ["lotnumber", "captchaoutput", "passtoken", "gentime"]);
  assert.deepEqual(event.queryFields, ["token", "appver", "timestamp"]);
  assert.match(result.logs.join("\n"), /app.request/);
});

test("response diagnosis records HTTP and encryption without reading any response body", () => {
  for (const [value, expected] of [["0", "none"], ["1", "SM2"], ["2", "AES"], [SECRET, "unknown"]]) {
    const result = run({ req: request(), response: { status: 200, headers: { "X-Encryption": value }, body: PII } });
    assert.equal(result.events()[0].http, 200);
    assert.equal(result.events()[0].encryption, expected);
    assert.match(result.logs.join("\n"), /businessCode=not_read bodyRead=false/);
  }
});

test("off or invalid diagnostic arguments never persist traffic events", () => {
  for (const argument of [{ app_diagnostic: false }, { app_diagnostic: "false" }, {}, "true", null]) {
    const result = run({ req: request(), argument });
    assert.equal(result.values.has(KEY), false);
    assert.match(result.logs.join("\n"), /disabled_or_invalid_argument/);
  }
});

test("diagnostics ignore page status, lookalike domains and unrelated endpoints", () => {
  for (const other of [url.replace("/signIn?", "/indexInfoV2?"), url.replace("miniapp.yaduo.com/", "miniapp.yaduo.com.evil.example/"), url.replace("/signIn?", "/signInExtra?")]) assert.equal(run({ req: request({ url: other }) }).values.has(KEY), false);
});

test("local failures cannot block request or response passthrough", () => {
  for (const fail of ["read", "write", "false"]) {
    run({ req: request(), fail });
    run({ req: request(), response: { status: 200, headers: {}, body: PII }, fail });
  }
  assert.equal(run({ req: request(), logFails: true }).events().length, 1);
});

test("report entry assembles both phases after the diagnostic switch has been disabled", () => {
  const first = run({ req: request() });
  const second = run({ req: request(), response: { status: 200, headers: {}, body: PII }, storage: Object.fromEntries(first.values) });
  const report = run({ storage: Object.fromEntries(second.values), argument: { app_diagnostic: false } });
  assert.equal(report.events().length, 2);
  assert.match(report.logs.join("\n"), /app.request/);
  assert.match(report.logs.join("\n"), /app.response/);
  assert.match(report.logs.join("\n"), /HTTP_200不代表业务成功/);
});

test("diagnostic storage retains only the latest 40 redacted events", () => {
  let storage = {};
  let result;
  for (let i = 0; i < 45; i++) {
    result = run({ req: request(), storage });
    storage = Object.fromEntries(result.values);
  }
  assert.equal(result.events().length, 40);
});

test("report validates stored event fields rather than printing arbitrary stored text", () => {
  // Store a tampered event; normalize it before any output.
  const storage = { [KEY]: JSON.stringify([{phase: "response", at: SECRET, http: SECRET, encryption: SECRET, body: PII}, {phase: "request", at: SECRET, method: SECRET, queryFields: [SECRET, "token"], captchaFields: [SECRET], url}]) };
  const values = new Map(Object.entries(storage));
  const logs = [], done = [];
  vm.runInNewContext(source, { console: { log: text => logs.push(String(text)) }, $persistentStore: { read: key => values.get(key) }, $done: (...args) => done.push(args) }, {timeout: 1000});
  assert.equal(done.length, 1);
  const output = logs.join("\n");
  assert.ok(!output.includes(SECRET));
  assert.ok(!output.includes(PII));
  assert.ok(!output.includes(url));
  assert.match(output, /at=unknown/);
});
