/*
 * 亚朵签到 · Loon 原生版
 * 2026-10-04 · 对照亚朵公开客户端 20260917191702 编写。
 * 登录信息仅保存在本机。只查询状态和尝试一次普通签到；要求验证码时停止。
 * 构建后的 atour.loon.js 内置标准密码库，运行时不下载依赖。
 */
(async function () {
  "use strict";
  var TITLE = "亚朵签到";
  var KEY = "atour_loon_session_v1";
  var BASE = "https://miniapp.yaduo.com";
  var INDEX = "/atourlife/signIn/indexInfoV2";
  var SIGN = "/atourlife/signIn/signIn";
  var intercept = typeof $request !== "undefined";
  var finished = false;
  var OMIT = /^(host|content-length|connection|accept-encoding|transfer-encoding|proxy-connection|lotnumber|captchaoutput|passtoken|gentime|lacktype)$/i;
  var DYNAMIC_QUERY = /^(sign|signature|nonce|timestamp|ts|lotnumber|captchaoutput|passtoken|gentime|lacktype)$/i;

  function tell(subtitle, message) {
    console.log(TITLE + "：" + subtitle + "；" + message);
    $notification.post(TITLE, subtitle, message);
  }
  function finish() {
    if (finished) return;
    finished = true;
    // Loon 的 HTTP rewrite 必须返回 {}，才会原样放行。
    if (intercept) $done({}); else $done();
  }
  function day() {
    var d = new Date();
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }
  function header(headers, name) {
    var names = Object.keys(headers || {});
    for (var i = 0; i < names.length; i++) {
      if (names[i].toLowerCase() === name.toLowerCase()) return String(headers[names[i]]);
    }
    return "";
  }
  function cleanHeaders(headers) {
    var result = {};
    Object.keys(headers || {}).forEach(function (key) {
      if (!OMIT.test(key) && key.toLowerCase() !== "at-client-sign" && typeof headers[key] === "string") result[key] = headers[key];
    });
    return result;
  }
  function parseUrl(url) {
    if (typeof url !== "string" || url.length > 32768) return null;
    var match = /^https:\/\/miniapp\.yaduo\.com(\/atourlife\/signIn\/(?:indexInfoV2|signIn))(?:\?([^#]*))?$/.exec(url);
    if (!match) return null;
    var query = match[2] || "";
    var params = {};
    try {
      query.split("&").forEach(function (part) {
        if (!part) return;
        var p = part.indexOf("=");
        var k = decodeURIComponent((p < 0 ? part : part.slice(0, p)).replace(/\+/g, " "));
        var v = decodeURIComponent((p < 0 ? "" : part.slice(p + 1)).replace(/\+/g, " "));
        if (Object.prototype.hasOwnProperty.call(params, k)) throw new Error("duplicate query");
        params[k] = v;
      });
    } catch (_) { return null; }
    return { path: match[1], query: query, params: params };
  }
  function hasDynamic(parsed, headers) {
    return !!header(headers, "At-Client-Sign") || Object.keys(parsed.params).some(function (k) { return DYNAMIC_QUERY.test(k); });
  }
  function hasLogin(parsed, headers) {
    return Object.keys(parsed.params).some(function (k) { return /^(token|appToken)$/i.test(k) && !!parsed.params[k]; }) ||
      ["authorization", "cookie", "token", "appToken"].some(function (k) { return !!header(headers, k); });
  }
  function identity(parsed, headers) {
    var data = {};
    Object.keys(parsed.params).sort().forEach(function (k) { if (/^(token|appToken)$/i.test(k)) data[k.toLowerCase()] = parsed.params[k]; });
    ["authorization", "cookie", "token", "appToken"].forEach(function (k) { if (header(headers, k)) data[k.toLowerCase()] = header(headers, k); });
    return JSON.stringify(data);
  }
  function readSession() {
    try {
      var saved = JSON.parse($persistentStore.read(KEY) || "null");
      if (!saved || typeof saved.headers !== "object" || Array.isArray(saved.headers) || !saved.headers) return null;
      var parsed = parseUrl(saved.url);
      if (!parsed || parsed.path !== INDEX || hasDynamic(parsed, saved.headers) || !hasLogin(parsed, saved.headers)) return null;
      saved.headers = cleanHeaders(saved.headers);
      return saved;
    } catch (_) { return null; }
  }
  function base64(text) {
    if (typeof text !== "string") throw new Error("encrypted");
    var s = text.trim().replace(/-/g, "+").replace(/_/g, "/");
    // JSON 字符串形式的密文由正常 JSON.parse 去引号后再解码。
    if (s.charAt(0) === '"') {
      s = JSON.parse(s);
      if (typeof s !== "string") throw new Error("encrypted");
      s = s.replace(/-/g, "+").replace(/_/g, "/");
    }
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(s) || s.length % 4 === 1) throw new Error("encrypted");
    s = s.replace(/=+$/, "");
    while (s.length % 4) s += "=";
    return __atourCrypto.CryptoJS.enc.Base64.parse(s);
  }
  function unpack(body, headers) {
    if (typeof body !== "string" || body.length > 524288) return { error: "格式异常" };
    var encryption = header(headers, "x-encryption").trim();
    try {
      var text = body;
      var C = __atourCrypto.CryptoJS;
      if (encryption === "1") {
        var hex = base64(body).toString(C.enc.Hex);
        if (hex.slice(0, 2) !== "04" || hex.length <= 194) throw new Error("encrypted");
        // 官网公开客户端内置常量；SM2 模式 0 = C1C2C3，并验证 SM3 C3。
        text = __atourCrypto.sm2.doDecrypt(hex.slice(2), "00d0242f0bcbd05beb53b0c7c3db7daa01c5d2b406e8cc6e94671771812b9e7568", 0);
        if (!text) throw new Error("encrypted");
      } else if (encryption === "2") {
        var cipher = base64(body);
        if (!cipher.sigBytes || cipher.sigBytes % 16) throw new Error("encrypted");
        // 先以 NoPadding 解密，再严格检查 PKCS7，避免库默认去 padding 接受畸形密文。
        var clear = C.AES.decrypt({ ciphertext: cipher }, C.enc.Utf8.parse("9vok8x4yri507ngmplhs3uq6cfbz2a1t"), {
          iv: C.enc.Utf8.parse("e9yu7sz2xrn30bf5"), mode: C.mode.CBC, padding: C.pad.NoPadding
        });
        var bytes = clear.words;
        var n = clear.sigBytes;
        var pad = (bytes[(n - 1) >>> 2] >>> (24 - ((n - 1) % 4) * 8)) & 255;
        if (pad < 1 || pad > 16 || pad > n) throw new Error("encrypted");
        for (var i = n - pad; i < n; i++) {
          if (((bytes[i >>> 2] >>> (24 - (i % 4) * 8)) & 255) !== pad) throw new Error("encrypted");
        }
        clear.sigBytes -= pad;
        clear.clamp();
        text = C.enc.Utf8.stringify(clear);
      } else if (encryption && encryption !== "0") {
        return { error: "未知响应加密，需要更新适配" };
      }
      var data = JSON.parse(text);
      if (!data || typeof data !== "object" || Array.isArray(data) || !Object.prototype.hasOwnProperty.call(data, "retcode")) return { error: "接口数据结构变化" };
      if (typeof data.retcode !== "number" && !(typeof data.retcode === "string" && /^-?\d+$/.test(data.retcode))) return { error: "接口数据结构变化" };
      var code = Number(data.retcode);
      if (!Number.isSafeInteger(code)) return { error: "接口数据结构变化" };
      return { code: code, result: data.result };
    } catch (_) { return { error: encryption && encryption !== "0" ? "响应解密失败，需要核对协议适配" : "响应不是有效 JSON" }; }
  }
  function complete(result) {
    if (!result || typeof result !== "object") return null;
    var value = result.todaySignInComplete;
    if (value === true || value === 1 || value === "true" || value === "1") return true;
    if (value === false || value === 0 || value === "false" || value === "0") return false;
    return null;
  }
  function saveAudit(session) {
    // 请求期间可能在 App 切换账号或刷新 token，不能用旧 session 覆盖新登录信息。
    var current = readSession();
    if (!current || identity(parseUrl(current.url), current.headers) !== identity(parseUrl(session.url), session.headers)) {
      console.log(TITLE + "：运行期间会话已更新，保留新登录信息；本次结果对应运行开始时使用的账号");
      return "；运行期间登录信息已更新，本次结果对应原账号";
    }
    current.signedDay = day();
    if (!$persistentStore.write(JSON.stringify(current), KEY)) console.log(TITLE + "：服务器已确认，本地记录保存失败");
    return "";
  }
  function capture() {
    if (typeof $response === "undefined" || String($request.method || "GET").toUpperCase() !== "GET") return;
    var parsed = parseUrl($request.url);
    if (!parsed) return;
    var http = Number($response.status || $response.statusCode);
    if (http !== 200) return;
    var response = unpack($response.body, $response.headers);
    if (response.error) { tell("获取登录信息失败", response.error + "；已有登录信息未被替换。"); return; }
    if (response.code !== 0) return;
    if (parsed.path === INDEX && complete(response.result) === null) return;
    if (hasDynamic(parsed, $request.headers)) {
      tell("需要动态签名适配", "本次请求含动态签名或时效参数，未保存。请重新打开 App 的签到页面获取普通状态请求。");
      return;
    }
    if (!hasLogin(parsed, $request.headers)) return;
    var session = { url: BASE + INDEX + (parsed.query ? "?" + parsed.query : ""), headers: cleanHeaders($request.headers), savedAt: Date.now() };
    if (parsed.path === SIGN || complete(response.result) === true) session.signedDay = day();
    var old = readSession();
    if (!$persistentStore.write(JSON.stringify(session), KEY)) {
      tell("保存失败", "未能保存登录信息，请检查 Loon 的本地存储后重新打开签到页面。");
      return;
    }
    // 避免每次打开签到页都通知；参数 r 变化不影响账号判断。
    var oldParsed = old && parseUrl(old.url);
    if (!oldParsed || identity(parsed, session.headers) !== identity(oldParsed, old.headers)) tell("登录信息已保存", "可在 Loon 中手动运行一次亚朵签到；每天 08:40 自动运行，验证码需在 App 完成。");
  }
  function freshUrl(session, path) {
    var parsed = parseUrl(session.url);
    var parts = parsed.query.split("&").filter(function (part) {
      return part && decodeURIComponent(part.split("=")[0]).toLowerCase() !== "r";
    });
    parts.push("r=" + String(Math.random()));
    return BASE + path + "?" + parts.join("&");
  }
  function get(session, path) {
    return new Promise(function (resolve) {
      try {
        $httpClient.get({ url: freshUrl(session, path), headers: cleanHeaders(session.headers), timeout: 15000, "auto-redirect": false, "auto-cookie": false }, function (error, response, body) {
          if (error) { resolve({ error: "网络请求失败" }); return; }
          var status = Number(response && (response.status || response.statusCode));
          if (status !== 200) { resolve({ error: "HTTP " + (Number.isFinite(status) ? status : "异常"), http: status }); return; }
          resolve(unpack(body, response.headers));
        });
      } catch (_) { resolve({ error: "请求未能发出" }); }
    });
  }
  function problem(reply, phase) {
    if (reply.code === 100042) tell("需要人工验证", "请在亚朵 App 完成验证码和今日签到。脚本已停止，不会重放验证信息。");
    else if (reply.code === 10002 || reply.http === 401 || reply.http === 403) tell("需要重新登录", "请在亚朵 App 重新登录并打开签到页面，更新 Loon 中的登录信息。");
    else if (reply.error) tell(phase, reply.error + "；请打开 App 核对签到状态。");
    else tell(phase, "接口业务码 " + reply.code + "；请在 App 核对，必要时更新脚本。");
  }
  async function run() {
    var session = readSession();
    if (!session) { tell("尚未获取有效登录信息", "请启用抓取规则并打开亚朵 App 的签到页面；保存后再手动运行。"); return; }
    var first = await get(session, INDEX);
    if (first.error || first.code !== 0) { problem(first, "查询失败"); return; }
    var signed = complete(first.result);
    if (signed === null) { tell("查询结果无法识别", "今日状态字段缺失或变化，需要更新适配；未提交签到。"); return; }
    if (signed) { var savedNote = saveAudit(session); tell("今日已签到", "服务器已确认今日签到完成" + savedNote + "。"); return; }
    // 只尝试一次普通签到。没有验证码结果或动态签名的伪造/重放。
    var submitted = await get(session, SIGN);
    if (submitted.error || submitted.code !== 0) { problem(submitted, "签到结果待确认"); return; }
    var checked = await get(session, INDEX);
    if (checked.error || checked.code !== 0) { problem(checked, "签到结果待确认"); return; }
    if (complete(checked.result) !== true) { tell("签到结果待确认", "提交已返回，但服务器尚未确认今日完成；请打开 App 核对。"); return; }
    var auditNote = saveAudit(session);
    // 仅输出可识别的碎片数量，不把服务器原文或用户信息送入日志/通知。
    var description = submitted.result && submitted.result.debrisDesc;
    var reward = typeof description === "string" && /^获得\s*(\d{1,3})\s*片碎片[。！! ]*$/.exec(description);
    tell("签到成功", "服务器已确认今日完成" + (reward ? "，获得 " + Number(reward[1]) + " 片碎片" : "") + auditNote + "。");
  }
  try {
    if (intercept) capture(); else await run();
  } catch (_) {
    tell("脚本运行异常", "请核对本地脚本和配置；登录信息不会写入通知或日志。");
  } finally { finish(); }
})();
