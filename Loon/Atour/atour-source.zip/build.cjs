"use strict";
// 本地、确定性构建；不下载、不安装、不执行外部应用源码。
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const root = __dirname;
const dependencies = [
  ["crypto-js-4.2.0.js", "ee02257ffbaf0a9b481c7039b0f3bb20c360c9674fe4be8b38ae709b2ea59bbe"],
  ["sm-crypto-sm2-0.3.13.js", "320dc9bed7f6a6be32c690f893f87c9c1e5dfd7d56e44dbec056080b3cf7a08d"]
];
const notices = ["crypto-js-4.2.0-LICENSE.txt", "sm-crypto-0.3.13-LICENSE.txt", "jsbn-1.1.0-LICENSE.txt"]
  .map(file => file + "\n" + fs.readFileSync(path.join(root, "vendor", file), "utf8")).join("\n\n");
const libraries = dependencies.map(([file, expected]) => {
  const data = fs.readFileSync(path.join(root, "vendor", file));
  const actual = crypto.createHash("sha256").update(data).digest("hex");
  if (actual !== expected) throw new Error("Dependency hash mismatch: " + file);
  return "\n/* bundled: " + file + " */\n" + data.toString("utf8") + "\n";
}).join("\n");
const wrapper = "var __atourCrypto = typeof $request === 'undefined' ? (function () {\n" +
  "var module, exports, define, self, window, global, require;\n" + libraries +
  "\nreturn { CryptoJS: this.CryptoJS, sm2: this.sm2 };\n}).call({}) : null;\n";
const code = "/*\n亚朵 Loon 原生签到 · 2026-10-04\n由 build.cjs 生成；可读主逻辑在 src/atour-main.js。\n第三方许可（库保持原始固定版本）：\n" + notices.replace(/\*\//g, "* /") + "\n*/\n" +
  wrapper + "\n" + fs.readFileSync(path.join(root, "src", "atour-main.js"), "utf8");
fs.writeFileSync(path.join(root, "atour.loon.js"), code);
console.log("Built atour.loon.js (" + Buffer.byteLength(code) + " bytes)");
